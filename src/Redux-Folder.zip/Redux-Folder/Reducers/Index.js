import {combineReducers} from 'redux';
import Profiledetails from './Profiledetails';
import RelatedTopicList from './RelatedTopicList';
import VideoAllDetail from './VideoAllDetail';
const allReducers = combineReducers({
    Profiledetails : Profiledetails,
    RelatedTopicList:RelatedTopicList,
    VideoAllDetail:VideoAllDetail
})

export default allReducers;