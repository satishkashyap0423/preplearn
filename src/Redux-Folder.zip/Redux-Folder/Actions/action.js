export const ProfileDetails = (userdetail)=>{
    return{
        type:"PROFILE",
        payload:userdetail
    }
}

export const RelatedTopicList = (topiclist)=>{
    return{
        type:"RELATEDTOPICLIST",
        payload:topiclist
    }
}

export const VideoAllDetail = (videodetail)=>{
    return{
        type:"VIDEODETAIL",
        payload:videodetail
    }
}
